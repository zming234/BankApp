
public interface interestRate {
	double interestRate();  
}
